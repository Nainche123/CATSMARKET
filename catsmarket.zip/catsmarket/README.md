# CATSMARKET Web (Final v1.0)

냥코 대전쟁 아이템 · 웹 자판기 최종본

## 실행
```bash
npm install
npm start
```
Windows: `START.bat`

http://localhost:3000

## 포함 기능
- Discord OAuth 로그인
- 포인트 충전 (토스뱅크) + 티어 보너스 (1만 5% / 3만 7% / 5만 10%)
- 상품 구매 · 세이브코드 제출 · 지급
- VIP 1~3 (할인 + Discord 역할)
- 쿠폰 · 추천인 · 인기상품 · 찜 · 검색/정렬
- 후기 (본인/관리자 삭제) · 공지 · 문의
- 관리자 패널 (`/admin`)
- Discord 임베드 알림 + 버튼

## .env 주요 항목
Discord / 은행 / VIP / 보너스 / 채널 ID 등은 `.env` 참고

## Discord VIP
```
DISCORD_GUILD_ID=
DISCORD_VIP1_ROLE_ID=
DISCORD_VIP2_ROLE_ID=
DISCORD_VIP3_ROLE_ID=
```

**이 버전을 최종본으로 사용하세요.**
